import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by the db_file
    :param db_file: database file
    :return: Connection object or None
    """
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)

    return None

def insert_record(record):
    """
    this is for getting the upc details
    :param mobile:
    :return:
    """
    database = "/home/vinbox/Desktop/mnpdb.db"
    conn = create_connection(database)
    with conn:
        cur = conn.cursor()
        cur.execute('''insert into customer_info (cust_name , email, mobile, company_name) values (?,?,?,?)''' , (record[0],record[1],record[2],record[3]))
        cur.execute("select * from customer_info")
        record1 = cur.fetchall()
        print(record1)
        return record1



# if __name__ == '__main__':
#     record = insert_record('Tarun','taurn1kumar1989@gmail.com','9958388950','Vinbox')
#     print(record)
