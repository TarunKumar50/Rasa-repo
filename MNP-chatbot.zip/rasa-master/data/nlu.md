## intent:Dont_know_UPC
- i dont have UPC
- i dont know my UPC
- dont have UPC
- what is UPC
- what is UPC
- can you tell me what is UPC
- where can i get UPC
- how can i get UPC

## intent:Helpdesk
- want to know about helpdesk
- helpdesk
- how can i contact helpdesk
- want to reach out to helpdesk
- /Helpdesk[{"category": "Helpdesk"}](category:Helpdesk)

## intent:Regulatory
- i want to enquire about regulatory
- i have some issue and want to talk to your regulatory
- can i talk to your regulatory team
- i want to talk to your regulatory team
- regulatory
- what is the contact details of your regulatory team
- can i talk to someone from your regulatory team
- /Regulatory[{"category": "Regulatory"}](category:Regulatory)

## intent:TSP_Login
- i want to login
- i am a tsp and i want to login
- how can i login as a TSP
- tsp login

## intent:affirm
- yes
- hmm
- yup
- yes , i have another query
- hmmmm
- yes please
- /affirm{"mnp module": affirmation"}
- /affirm{"mnp module": affirmation"}

## intent:bye
- goodbye
- goodnight
- good bye
- good night
- see ya
- bye bye
- gotta go
- catch you later
- bye for now
- bye
- bye was nice talking to you
- bye udo
- bye bye bot
- bye bot
- k byyye #slay
- tlak to you later
- ciao
- Bye bye
- then bye
- bye!
- bye
- bye

## intent:deny
- no
- NO
- nope
- no , thanks
- no thankyou
- /deny{"mnp module": denial"}
- /deny{"mnp module": denial"}
- /deny{"mnp module": denial"}
- /deny{"mnp module": denial"}

## intent:feedback
- /feedback[{"feedback_value":"positive"}](feedback_value:positive)
- /feedback[{"feedback_value":"positive"}](feedback_value:positive)
- /feedback[{"feedback_value":"negative"}](feedback_value:negative)
- /feedback[{"feedback_value":"positive"}](feedback_value:positive)
- /feedback[{"feedback_value":"positive"}](feedback_value:positive)
- /feedback[{"feedback_value":"positive"}](feedback_value:positive)

## intent:get_started
- on intial prompt this will show on chatbot
- pass

## intent:greet
- hello
- hey
- hi
- anyone there?
- anybody there?
- please help
- help
- help me please
- i need help
- anyone there to help
- hi
- hey
- hey
- hey

## intent:inform
- [9958388950](MSISDN)
- [AH219235](UPC)
- [9810109585](MSISDN)
- [ID234578](UPC)
- it's [6789123456](MSISDN)
- ok its [7812347856](MSISDN)
- my mobile number is [9958388950](MSISDN)
- mobile number is [9958388950](MSISDN)
- my UPC is [BH123456](UPC)
- UPC is [RH234567](UPC)
- [9912345678](MSISDN)
- [9812345678](MSISDN)
- [6712345678](MSISDN)
- [9812398723](MSISDN)
- [6301237843](MSISDN)
- [7802342378](MSISDN)
- [8723458900](MSISDN)
- [6902345678](MSISDN)
- [9958388950](MSISDN)
- [AH123456](UPC)
- [9810109585](MSISDN)
- [9958388950](MSISDN)
- [AH123456](UPC)
- [9958388950](MSISDN)
- [AH123456](UPC)
- [9958388950](MSISDN)
- [9958388950](MSISDN)

## intent:out_of_scope
- mc
- bc
- teri ma ki

## intent:port_status
- i want to know port status of my mobile number [9958388950](MSISDN)
- can i know port status
- what is the port status of my number
- port status
- [9958388950](MSISDN)
- Please tell me port status
- tell me port status
- my port status
- port status
- port status
- port status

## intent:thanks
- thankyou
- thanks
- thank
- thanks
- thanks
- thanks
- thanks

## intent:upc_status
- i want to enquire about UPC
- can you tell me my UPC status
- UPC status
- what is my UPC status
- i want to know my UPC
- tell me my UPC
- i want upc status for [9958388950](MSISDN)
- upc status for [9810109585](MSISDN)
- upc status [9958388950](MSISDN)
- /upc_status[{"category": "UPC Status"}](category:UPC Status)
- /upc_status[{"category": "UPC Status"}](category:UPC Status)
- upc status

## synonym:Helpdesk
- {"category": "Helpdesk"}

## synonym:Regulatory
- {"category": "Regulatory"}

## synonym:UPC Status
- {"category": "UPC Status"}

## synonym:negative
- {"feedback_value":"negative"}

## synonym:positive
- {"feedback_value":"positive"}

## regex:MSISDN
- ([0-9]{10})

## regex:UPC
- ([a-zA-Z]{2}[0-9]{6})
