## story_01
* greet
  - utter_greet
* port_status{"MSISDN":"9958388950"}
  - slot{"MSISDN":"9958388950"}
  - utter_ask_upc
* inform{"UPC":"AH123456"}
  - slot{"UPC":"AH123456"}
  - action_MNP_record
* thanks
  - utter_anything_else
* affirm
  - utter_ask_again
* upc_status{"MSISDN":"9958388950"}
  - slot{"MSISDN":"9958388950"}
  - action_upc_record
* thanks
  - utter_anything_else
* deny
  - utter_ask_feedback
* feedback{"feedback_value":"positive"}
  - slot{"feedback_value":"positive"}
  - utter_positive_feedback
  - action_restart
  
## story_02
* greet
  - utter_greet
* port_status
  - utter_ask_MSISDN
* inform{"MSISDN":"9810109585"}
  - slot{"MSISDN":"9810109585"}
  - utter_ask_upc
* inform{"UPC":"AH123456"}
  - action_MNP_record
* thanks
  - utter_anything_else
* affirm
  - utter_ask_again
* TSP_Login
  - utter_tsp_login
  - utter_anything_else
* deny
  - utter_ask_feedback
* feedback{"feedback_value":"positive"}
  - slot{"feedback_value":"positive"}
  - utter_positive_feedback
  - action_restart

## story_03
* port_status
  - utter_ask_MSISDN
* inform{"MSISDN":"9810109585"}
  - slot{"MSISDN":"9810109585"}
  - utter_ask_upc
* inform{"UPC":"BH234567"}
  - slot{"UPC":"BH234567"}
  - action_MNP_record
* thanks
  - utter_anything_else
* deny
  - utter_ask_feedback
* feedback{"feedback_value":"positive"}
  - slot{"feedback_value":"positive"}
  - utter_positive_feedback
  - action_restart
 
## story_04
* greet
  - utter_greet
  
## story_05
* thanks
  - utter_welcome
  
## story_06
* port_status
  - utter_ask_MSISDN
* inform{"MSISDN":"9810109585"}
  - slot{"MSISDN":"9810109585"}
  - utter_ask_upc
* inform{"UPC":"AB123456"}
  - slot{"UPC":"AB123456"}
  - action_MNP_record
  
## story_07
* out_of_scope
  - utter_out_of_scope

## story_08
* get_started
  - utter_message_on_prompt
  
## story_09
* Regulatory
  - utter_ask_regulatory
  - utter_ask_again
* port_status{"MSISDN":"9958388950"}
  - slot{"MSISDN":"9958388950"}
  - utter_ask_upc
* inform{"UPC":"AH123456"}
  - slot{"UPC":"AH123456"}
  - action_MNP_record
  - utter_anything_else
* deny
  - utter_ask_feedback
* feedback{"feedback_value":"negative"}
  - slot{"feedback_value":"negative"}
  - utter_negative_feedback
  - action_restart
  
## story_10
* TSP_Login
  - utter_tsp_login
  - utter_ask_again
* upc_status
  - utter_ask_MSISDN
* inform{"MSISDN":"9810109585"}
  - slot{"MSISDN":"9810109585"}
  - action_upc_record
  - utter_anything_else
* deny
  - utter_ask_feedback
* feedback{"feedback_value":"negative"}
  - slot{"feedback_value":"negative"}
  - utter_negative_feedback
 
## story_11
* upc_status
  - utter_ask_MSISDN
* inform{"MSISDN":"9958388950"}
  - slot{"MSISDN":"9958388950"}
  - action_upc_record
  - utter_anything_else
* affirm 
  - utter_ask_again
* Regulatory
  - utter_ask_regulatory
  - utter_anything_else
* deny
  - utter_ask_feedback
* feedback{"feedback_value":"positive"}
  - slot{"feedback_value":"positive"}
  - utter_positive_feedback

## story_12
* inform{"MSISDN":"9810109585"}
  - slot{"MSISDN":"9810109585"}
  - utter_ask_upc
* inform{"UPC":"BH234567"}
  - slot{"UPC":"BH234567"}
  - action_MNP_record
* thanks
  - utter_anything_else
* affirm
  - utter_ask_again
* Regulatory
  - utter_ask_regulatory
  - utter_anything_else
* deny
  - utter_ask_feedback
* feedback{"feedback_value":"negative"}
  - slot{"feedback_value":"negative"}
  - utter_negative_feedback

## story_13
* bye
  - utter_bye
  - utter_ask_feedback
* feedback{"feedback_value":"positive"}
  - slot{"feedback_value":"positive"}
  - utter_positive_feedback

## ask feedback + negative
  - utter_ask_feedback
* feedback{"feedback_value":"negative"}
  - slot{"feedback_value":"negative"}
  - utter_negative_feedback

## feedback + positive
  -utter_ask_feedback
* feedback{"feedback_value":"positive"}
  - slot{"feedback_value":"positive"}
  - utter_positive_feedback

## port status without MSISDN
* port_status
  - utter_ask_MSISDN

## port status with MSISDN
* port_status{"MSISDN":"9958388950"}
  - slot{"MSISDN":"9958388950"}
  - utter_ask_upc

## Helpdesk
* Helpdesk
  - utter_Helpdesk
  - utter_ask_again

## interactive_story_1
* greet
    - utter_greet
* port_status
    - utter_ask_MSISDN
* inform{"MSISDN": "9958388950"}
    - slot{"MSISDN": "9958388950"}
    - utter_ask_upc
* inform{"UPC": "AH123456"}
    - slot{"UPC": "AH123456"}
    - action_MNP_record
* thanks
    - utter_anything_else
* affirm
    - utter_ask_again
* upc_status{"category": "UPC Status"}
    - utter_ask_MSISDN
* inform{"MSISDN": "9810109585"}
    - slot{"MSISDN": "9810109585"}
    - action_upc_record
    - utter_anything_else
* deny
    - utter_ask_feedback
* feedback{"feedback_value": "positive"}
    - slot{"feedback_value": "positive"}
    - utter_positive_feedback
* bye
    - utter_bye
    - utter_ask_feedback
* feedback{"feedback_value": "positive"}
    - slot{"feedback_value": "positive"}
    - utter_positive_feedback
* TSP_Login
    - utter_tsp_login
    - utter_ask_again
* Regulatory{"category": "Regulatory"}
    - utter_ask_regulatory
    - utter_ask_again
* Helpdesk{"category": "Helpdesk"}
    - utter_Helpdesk
    - utter_ask_again
* thanks
    - utter_welcome
* bye
    - utter_bye
    - utter_ask_feedback
* feedback{"feedback_value": "negative"}
    - slot{"feedback_value": "negative"}
    - utter_negative_feedback
    - action_restart

## interactive_story_1
* greet
    - utter_greet

## interactive_story_2
* greet
    - utter_greet
* greet
    - utter_greet
* greet
    - utter_greet

## interactive_story_1
* greet
    - utter_greet

## interactive_story_1
* greet
    - utter_greet
* port_status
    - utter_ask_MSISDN
* inform{"MSISDN": "9958388950"}
    - slot{"MSISDN": "9958388950"}
    - utter_ask_upc
* inform{"UPC": "AH123456"}
    - slot{"UPC": "AH123456"}
    - action_MNP_record
* thanks
    - utter_anything_else
* deny
    - utter_ask_feedback
* feedback{"feedback_value": "positive"}
    - slot{"feedback_value": "positive"}
    - utter_positive_feedback
    - action_restart

## interactive_story_1
* port_status
    - utter_ask_MSISDN
* inform{"MSISDN": "9958388950"}
    - slot{"MSISDN": "9958388950"}
    - utter_ask_upc
* inform{"UPC": "AH123456"}
    - slot{"UPC": "AH123456"}
    - action_MNP_record
* thanks
    - utter_anything_else
* affirm
    - utter_ask_again
* upc_status{"category": "UPC Status"}
    - utter_ask_MSISDN
* inform{"MSISDN": "9958388950"}
    - slot{"MSISDN": "9958388950"}
    - action_upc_record
    - utter_anything_else
* deny
    - utter_ask_feedback
* feedback{"feedback_value": "positive"}
    - slot{"feedback_value": "positive"}
    - utter_positive_feedback

## interactive_story_1
* greet
    - utter_greet
* upc_status
    - utter_ask_MSISDN
* inform{"MSISDN": "9958388950"}
    - slot{"MSISDN": "9958388950"}
    - action_upc_record
    - utter_anything_else
* deny
    - utter_ask_feedback
* feedback{"feedback_value": "positive"}
    - slot{"feedback_value": "positive"}
    - utter_positive_feedback
    - action_restart
