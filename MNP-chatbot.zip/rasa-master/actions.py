from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
#from rasa_core.events import AllSlotsReset
#from rasa_core.events import Restarted
from dbconnection import select_specific, select_upc
import sys
from rasa_sdk import Action
from rasa_sdk.events import SlotSet

class ActionfetchMNP(Action):
   def name(self):
      # type: () -> Text
      return 'action_MNP_record'


   def run(self, dispatcher, tracker, domain):
      # type: (CollectingDispatcher, Tracker, Dict[Text, Any]) -> List[Dict[Text, Any]]

      try:
          MSISDN_entered = tracker.get_slot('MSISDN')
          UPC = tracker.get_slot('UPC')
          if len(MSISDN_entered)!=10 and len(UPC)!=8:
              dispatcher.utter_message('Enter MSISDN or UPC is not correct, Please correct')
          else:
              rows = select_specific(MSISDN_entered,UPC)
              print("actions file ",len(rows))
              if len(rows)!=0:
                  for row in rows:
                      print(row)
                      if row[5].lower() == 'succ':
                          response= 'MNP status for Mobile number : {} request received on : {} current status : {}'
                          dispatcher.utter_message(response.format(row[1], row[2], row[3]))
                      elif row[5].lower() == 'reject':
                          response='''
                      MNP status for Mobile number : {}...
                      Request received on : {}
                      Current status  : {}
                      Rejection reason : {}'''
                          dispatcher.utter_message(response.format(row[1], row[2], row[3], row[4]))
              else:
                  dispatcher.utter_message("There are no records for MSISDN {}".format(MSISDN_entered))
      except:
          print("Oops!",sys.exc_info()[0]," occured")

class ActionRestarted(Action):
    def name(self):
        return 'action_restarted'
    def run(self, dispatcher, tracker, domain):
        return[Restarted()]

class ActionfetchUPC(Action):
    def name(self):
        return 'action_upc_record'

    def run(self, dispatcher, tracker, domain):
      # type: (CollectingDispatcher, Tracker, Dict[Text, Any]) -> List[Dict[Text, Any]]

      try:
          MSISDN_entered = tracker.get_slot('MSISDN')
          rows = select_upc(MSISDN_entered)
          print("actions file ",len(rows))
          if len(rows)!=0:
            for row in rows:
                response= '''
    UPC status for Mobile number : {}
    UPC request received on : {}
    UPC delivery status : {}'''
                dispatcher.utter_message(response.format(row[1],row[3],row[4]))
          else:
            dispatcher.utter_message("We haven't received UPC request for MSISDN {}".format(MSISDN_entered))
      except:
          print("Oops!",sys.exc_info()[0]," occured")
