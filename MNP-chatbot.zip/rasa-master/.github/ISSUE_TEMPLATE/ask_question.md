---
name: Ask a question
about: If you have a "How do I?" question please ask in the forum https://forum.rasa.com
title: ''
labels: question
assignees: ''

---

<!--
PLEASE DO NOT CREATE ISSUES TO ASK QUESTIONS, THEY WILL BE CLOSED:

Hi! If you have a question about how to do something with Rasa, we are happy
to help out!

Please ask these questions in the forum (https://forum.rasa.com).

We only use Github issues for bugs and feature requests. -->
