:desc: Check out the API docs for open source chatbot framework Rasa's
       action server, which allows you to define your own custom actions.

:pagetype: full

.. _action-server:

Action Server
=============

.. raw:: html

    <redoc spec-url='../../_static/spec/action-server.yml'></redoc>
    <script src="https://cdn.jsdelivr.net/npm/redoc@next/bundles/redoc.standalone.js"> </script>
