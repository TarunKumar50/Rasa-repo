:desc: The Agent class provides a central interface for performing crucial
       operations like training, handling messages, loading a model, and
       action prediction.

.. _agent:

Agent
=====

.. edit-link::
   :url: https://github.com/RasaHQ/rasa/edit/master/rasa/core/agent.py
   :text: SUGGEST DOCSTRING EDITS

.. autoclass:: rasa.core.agent.Agent
   :members:
