:desc: Read about Rasa's HTTP API that has endpoints for conversations,
       training models, and configuring your bot.

:pagetype: full

.. _http-api:

HTTP API
========

.. raw:: html

    <redoc spec-url='../../_static/spec/rasa.yml'></redoc>
    <script src="https://cdn.jsdelivr.net/npm/redoc@next/bundles/redoc.standalone.js"> </script>